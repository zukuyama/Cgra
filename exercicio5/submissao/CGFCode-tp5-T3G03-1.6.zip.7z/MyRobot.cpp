#include "MyRobot.h"


MyRobot::MyRobot()
{
	angle = 210.0;
	x = 9;
	y = 0;
	z = 8;
}


double MyRobot::degToRad(double deg)
{
	return (deg * 3.1415926535) / 180.0;
}


void MyRobot::draw()
{
	GLUquadric *pyramid = gluNewQuadric();
	gluQuadricTexture(pyramid, GL_TRUE);


	glMatrixMode(GL_TEXTURE);
	//Push the matrix to the stack and modify it
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(1.0f, 1.5f, 4.0f);
	glScalef(1.1f, 1.2f, 1.2f);
	glMatrixMode(GL_MODELVIEW);
	glTranslatef(x, y, z);
	glRotated(-90, 1, 0, 0);
	glRotated(-angle, 0, 0, 1);
	gluCylinder(pyramid, 0.5, 0.25, 1.0, 4, 5.0); 
	glTranslated(0, 0, 1);
	gluDisk(pyramid, 0.0, 0.25, 12, 1);

	//Make it active again and pop it
	glMatrixMode(GL_TEXTURE);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}


void MyRobot::setAngle(int angle)
{
	this -> angle = angle % 360;
}


double MyRobot::getAngle() const 
{
	return angle;
}


void MyRobot::setX(double x)
{
	this -> x = x;
}


void MyRobot::setY(double y)
{
	this -> y = y;
}


void MyRobot::setZ(double z)
{
	this -> z = z;
}


double MyRobot::getX() const 
{
	return x;
}


double MyRobot::getY() const 
{
	return y;
}


double MyRobot::getZ() const 
{
	return z;
}



void MyRobot::moveRobot(bool inverse)
{
	double radians = degToRad(angle);

	if(!inverse)
	{
		setX(x + 0.2 * cos(radians));
		setZ(z + 0.2 * sin(radians));
	} else 
	{
		setX(x - 0.2 * cos(radians));
		setZ(z - 0.2 * sin(radians));
	}
}


void MyRobot::moveForward()
{
	setZ(z - 1);
	setX(x - 1);
	draw();
}



void MyRobot::moveBack()
{
	setZ(z + 1);
	setX(x + 1);
	draw();
}


void MyRobot::moveRight()
{
	setZ(z + 1);
	setX(x - 1);
	draw();
}


void MyRobot::moveLeft()
{
	setZ(z - 1);
	setX(x + 1);
}