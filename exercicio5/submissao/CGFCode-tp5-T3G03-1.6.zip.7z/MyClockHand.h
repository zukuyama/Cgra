#ifndef MY_CLOCK_HAND_
#define MY_CLOCK_HAND_
#include <math.h>


class MyClockHand {

private:
	float angle, length;

public:
	MyClockHand( float length);
	float getAngle();
	void setAngle(float angle);
	void draw(double angle, double size);
};

#endif