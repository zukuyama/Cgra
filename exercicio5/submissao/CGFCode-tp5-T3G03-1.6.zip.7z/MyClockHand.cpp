#include "ExampleObject.h"
#include "MyClockHand.h"


float pi2 = acos(-1.0);


MyClockHand::MyClockHand( float length){
	this->angle = 0;
	this->length = length;
}


float MyClockHand::getAngle(){
	return angle;
}


void MyClockHand::setAngle(float angle){
	this->angle = angle;
}


void MyClockHand::draw(double angle2, double size) {
	glLineWidth(2);
	glPushMatrix();

	glTranslatef(0.0, 0, 5);
	glRotated(angle2, 0, 0, 1);
	glBegin(GL_LINES);
	glVertex3f(0.0, 0.0, 2.0);
	glVertex3f(0.0, size, 2.0);
	glEnd();
	glPopMatrix();
}