#include "TPinterface.h"
#include "LightingScene.h"

TPinterface::TPinterface()
{
	var1 = var2 = var3 = var4 = var5 = var6 = 0;
}


void TPinterface::processKeyboard(unsigned char key, int x, int y)
{
	//Uncomment below if you would like to process the default keys (e.g. 's' for snapshot, 'Esc' for exiting, ...)
	//CGFinterface::processKeyboard(key, x, y);
	switch(key)
	{
		case 'a':
		{
			// This is an example of accessing the associated scene
			// To test, create the function toggleSomething in your scene to activate/deactivate something
			((LightingScene *) scene)->toggleSomething();
			break;
		}

		case 'j':
		{
			float angle = ((LightingScene *) scene)->getRobot()->getAngle();
			((LightingScene *) scene)->getRobot()->setAngle(angle - 5.0);
			((LightingScene *) scene)->getRobot()->draw();
			break;
		}

		case 'l':
		{
			float angle = ((LightingScene *) scene)->getRobot()->getAngle();
			((LightingScene *) scene)->getRobot()->setAngle(angle + 5.0);
			((LightingScene *) scene)->getRobot()->draw();
			break;
		}


		case 'i':
		{
			((LightingScene *) scene)->getRobot()->moveRobot(false);
			break;
		}


		case 'k':
		{
			((LightingScene *) scene)->getRobot()->moveRobot(true);
			break;
		}
	}
}

void TPinterface::initGUI()
{
	// Check CGFinterface.h and GLUI documentation for the types of controls available
	varPanel = addPanel("Luzes", 1);
	addCheckboxToPanel(varPanel, "Luz 1", &var1, 0);
	addCheckboxToPanel(varPanel, "Luz 2", &var2, 1);
	addCheckboxToPanel(varPanel, "Luz 3", &var3, 2);
	addCheckboxToPanel(varPanel, "Luz 4", &var4, 3);

	list = addListbox("Texturas: ", &var5, 4);
	list->add_item(5, "Robot1.jpg");
	list->add_item(6, "floor.png");
	list->add_item(7, "wall.png");
	list->add_item(8, "table.png");

	drawMode = addPanel("Modo de desenho", 9);
	GLUI_RadioGroup *group = addRadioGroupToPanel(drawMode, &var6, 10);
	addRadioButtonToGroup(group, "Textured");
	addRadioButtonToGroup(group, "Wireframe");

	clockPanel = addPanel("Rel�gio", 11);
	addCheckboxToPanel(clockPanel, "Reiniciar/Continuar", &var7, 12);
}

void TPinterface::processGUI(GLUI_Control *ctrl)
{
	int turned_on, texture_id, id_mode, clockVar;
	vector<CGFlight *> lights = ((LightingScene *) scene)->getLights();


	switch (ctrl->user_id)
	{
	case 0:
		turned_on = ctrl->get_int_val();
		if(turned_on)
			lights[0]->enable();
		else
			lights[0]->disable();
		break;


	case 1:
		turned_on = ctrl->get_int_val();
		if(turned_on)
			lights[1]->enable();
		else
			lights[1]->disable();
		break;


	case 2:
		turned_on = ctrl->get_int_val();
		if(turned_on)
			lights[2]->enable();
		else
			lights[2]->disable();
		break;


	case 3:
		turned_on = ctrl->get_int_val();
		if(turned_on)
			lights[3]->enable();
		else
			lights[3]->disable();
		break;


	case 4:
		texture_id = ctrl->get_int_val();
		if(texture_id == 5)
			((LightingScene *) scene)->setRobotTexture("robot1.jpg");
		else if(texture_id == 6)
			((LightingScene *) scene)->setRobotTexture("floor.png");
		else if(texture_id == 7)
			((LightingScene *) scene)->setRobotTexture("wall.png");
		else if(texture_id == 8)
			((LightingScene *) scene)->setRobotTexture("table.png");
		break;



	case 10:
		id_mode = ctrl->get_int_val();
		if(id_mode == 0)
			((LightingScene *) scene)->setSceneMode(GL_FILL);
		else
			((LightingScene *) scene)->setSceneMode(GL_LINE);
		break;



	case 12:
		clockVar = ctrl->get_int_val();
		//Pause the clock
		if(clockVar == 0)
			((LightingScene *) scene)->changeClockUpdate(false);
		else
			((LightingScene *) scene)->changeClockUpdate(true);
		break;
	};
}

