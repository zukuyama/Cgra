#pragma once
#ifndef MYROBOT_H_
#define MY_ROBOT_H_
#include "CGFobject.h"
#include <cmath>
#include <iostream>
using std::cos;
using std::sin;
using std::cout;
using std::endl;


class MyRobot : public CGFobject
{
private:
	double angle;
	double x, y, z;

public:
	MyRobot();
	void draw();
	void rotateLeft();
	void rotateRight();
	void setAngle(int angle);
	double getAngle() const;
	double getX() const;
	double getY() const;
	double getZ() const;
	void setX(double x);
	void setY(double y);
	void setZ(double z);
	void moveRobot(bool inverse);
	void moveForward();
	void moveBack();
	void moveRight();
	void moveLeft();
	double degToRad(double deg);
};
#endif