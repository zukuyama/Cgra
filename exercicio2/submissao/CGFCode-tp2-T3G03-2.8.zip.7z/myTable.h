#ifndef EXAMPLEOBJECT_H
#define EXAMPLEOBJECT_H

#include "CGFobject.h"


class myTable: public CGFobject {
	
	public:
		void draw();
};

#endif