#include "MyClock.h"
#include "myTable.h"
#include "CGFapplication.h"
#include "CGFappearance.h"
#include "myUnitCube.h"


MyClock::MyClock() :
	shouldUpdate(true), tolerance(0)
{
	float ambslidesAppearance[3] = {0.2, 0.2, 0.2};
	float difslidesAppearance[3] = {0.8, 0.8, 0.8};
	float specslidesAppearance[3] = {0.2, 0.2, 0.2};
	float shininessslidesAppearance = 60.f;


	clockAppearance = new CGFappearance(ambslidesAppearance,difslidesAppearance,specslidesAppearance,shininessslidesAppearance);
	clockAppearance->setTexture("clock.png");
	clockAppearance->setTextureWrap(GL_REPEAT,GL_REPEAT);

	hours = new MyClockHand(0.4);
	minutes = new MyClockHand(0.6);
	seconds = new MyClockHand(0.7);

	hoursAngle = 90;
	minutesAngle = 180;
	secondsAngle = 270;

	hours->setAngle(hoursAngle);
	minutes->setAngle(minutesAngle);
	seconds->setAngle(secondsAngle);

	time(&curTime);
	timeInfo = localtime(&curTime);
	time(&clockTime);
	clockInfo = localtime(&clockTime);
}


void MyClock::update(unsigned long millis)
{
	if(shouldUpdate)
		getCurrentTime();
	else {
		time(&toleranceTime);
		tolerance = difftime(toleranceTime, clockTime);
	}
}


void MyClock::draw()
{
	//Desenho do relogio com a textura
	glPushMatrix();
		GLUquadricObj *quadratic=gluNewQuadric();
		gluQuadricTexture(quadratic, GL_TRUE);
		clockAppearance->apply();
		gluCylinder(quadratic,1.0f,1.0f,5.0f,12,2);
		gluDisk(quadratic, 0.0f, 1.0f, 12, 1);
		glTranslatef(0.0f, 0.0f, 5.0f);		
		gluDisk(quadratic, 0.0f, 1.0f, 12, 1);	
		glTranslatef(0.0f, 0.0f, -5.0f);
	glPopMatrix();

	
	//Ponteiros
	glPushMatrix();
		hours->draw(-hours->getAngle(), 0.3f);
	glPopMatrix();

	glPushMatrix();
		minutes->draw(-minutes->getAngle(), 0.5f);
	glPopMatrix();

	glPushMatrix();
		seconds->draw(-seconds->getAngle(), 0.6f);
	glPopMatrix();
}



void MyClock::drawCenter(){
	float x1 = 0.0, y1 = 0.0, x2, y2, angle;
	double radius = 0.035;

	glColor3f(0.0,0.0,0.0);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(x1, y1);
	for (angle=1.0; angle <= 360.0; angle += 0.2 ) {
		x2 = x1 + sin(angle)*radius;
		y2 = y1 + cos(angle)*radius;
		glVertex2f(x2, y2);
	}
	glEnd();
}


void MyClock::getCurrentTime()
{
	int curHours, curMinutes, curSeconds, toleranceHours, toleranceMinutes, toleranceSeconds;

	time(&lastTime);
	int sec = difftime(lastTime, clockTime);
	toleranceHours = (tolerance / 60 / 60) % 24;
	toleranceMinutes = (tolerance / 60) % 60;
	toleranceSeconds = tolerance;
	curHours = ((sec / 60 / 60) % 24) + timeInfo->tm_hour - toleranceHours;
	curMinutes = ((sec / 60) % 60) + timeInfo->tm_min - toleranceMinutes;
	curSeconds = (timeInfo->tm_sec + sec - toleranceSeconds) % 60;
	clockInfo->tm_hour = curHours;
	clockInfo->tm_min = curMinutes;
	clockInfo->tm_sec = curSeconds;
	clockTime = mktime(clockInfo);


	if(curHours > 12)
		curHours -= 12;


	hoursAngle = 30 * curHours;
	minutesAngle = 6.0 * curMinutes;
	secondsAngle = 6.0 * curSeconds;


	hoursAngle += ((float)1/12.0 * minutesAngle);


	hours->setAngle(hoursAngle);
	minutes->setAngle(minutesAngle);
	seconds->setAngle(secondsAngle);
}


bool MyClock::getShouldUpdate()
{
	return shouldUpdate;
}


void MyClock::setShouldUpdate(bool update)
{
	this->shouldUpdate = update;	
}