#ifndef My_Clock
#define My_Clock
#include "CGFobject.h"
#include "CGFappearance.h"
#include "myUnitCube.h"
#include "MyClockHand.h"
#include <cmath>
#include <math.h>
#include <gl\GLU.h>
#include <GL\GLU.h>
#include <time.h>
#include <math.h>
#include <iostream>
using namespace std;


class MyClock : public CGFobject {

private:
	CGFappearance* clockAppearance;
	MyClockHand* hours;
	MyClockHand* minutes;
	MyClockHand* seconds;
	float hoursAngle, minutesAngle, secondsAngle;
	bool shouldUpdate;
	time_t curTime, lastTime, toleranceTime, clockTime;
	struct tm* timeInfo;
	struct tm* clockInfo;
	int tolerance;



public:
	MyClock();
	void update(unsigned long millis);
	void drawCenter();
	void draw();
	void getCurrentTime();
	bool getShouldUpdate();
	void setShouldUpdate(bool update);
};



#endif
