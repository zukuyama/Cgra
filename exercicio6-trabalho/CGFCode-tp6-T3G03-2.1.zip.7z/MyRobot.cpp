#include "MyRobot.h"

MyRobot::MyRobot()
{
	angle = 210.0;
	x = 9;
	y = 0;
	z = 8;
}


void MyRobot::draw()
{
	glTranslated(x, y, z);
	glRotated(angle, 0, 1, 0);
	glBegin(GL_TRIANGLES);
		glVertex3f(0.5, 0.3, 0);
		glVertex3f(-0.5, 0.3, 0);
		glVertex3f(0, 0.3, 2.0);
	glEnd();
}


void MyRobot::setAngle(int angle)
{
	this -> angle = angle % 360;
}


int MyRobot::getAngle() const 
{
	return angle;
}


void MyRobot::setX(int x)
{
	this -> x = x;
}


void MyRobot::setY(int y)
{
	this -> y = y;
}


void MyRobot::setZ(int z)
{
	this -> z = z;
}


int MyRobot::getX() const 
{
	return x;
}


int MyRobot::getY() const 
{
	return y;
}


int MyRobot::getZ() const 
{
	return z;
}



void MyRobot::moveRobot(bool inverse)
{
	if(angle == 210.0)
	{
		if(!inverse)
			moveForward();
		else 
			moveBack();
	} else if(angle == 30.0)
	{
		if(!inverse)
			moveBack();
		else 
			moveForward();
	} else if(angle == 300.0)
	{
		if(!inverse)
			moveRight();
		else
			moveLeft();
	} else if(angle == 120.0)
	{
		if(!inverse)
			moveLeft();
		else
			moveRight();
	}
}


void MyRobot::moveForward()
{
	setZ(z - 1);
	setX(x - 1);
	draw();
}



void MyRobot::moveBack()
{
	setZ(z + 1);
	setX(x + 1);
	draw();
}


void MyRobot::moveRight()
{
	setZ(z + 1);
	setX(x - 1);
	draw();
}


void MyRobot::moveLeft()
{
	setZ(z - 1);
	setX(x + 1);
}