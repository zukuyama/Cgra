#ifndef MY_CLOCK_HAND_
#define MY_CLOCK_HAND_

class MyClockHand {

private:
	float angle, thickness, length, red, green, blue;

public:
	MyClockHand(float thickness, float length, float red, float green, float blue);
	float getAngle();
	void setAngle(float angle);
	void draw();
};

#endif