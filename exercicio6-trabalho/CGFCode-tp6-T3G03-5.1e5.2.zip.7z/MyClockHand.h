#ifndef MY_CLOCK_HAND_
#define MY_CLOCK_HAND_

#include "myCylinder.h"
class MyClockHand {

private:
	float angle, length;

public:
	MyClockHand( float length);
	myCylinder* ponteiro;
	float getAngle();
	void setAngle(float angle);
	void draw();
};

#endif