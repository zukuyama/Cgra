#include "myCylinder.h"

myCylinder::myCylinder(int slices, int stacks) {

		
}

void myCylinder::drawCylinder(int slices, int stacks){                 
	GLUquadricObj *quadratic=gluNewQuadric();
	gluCylinder(quadratic,1.0f,1.0f,5.0f,slices,stacks);
}


/*slices
Specifies the number of subdivisions around the z axis.

stacks
Specifies the number of subdivisions along the z axis.*/

