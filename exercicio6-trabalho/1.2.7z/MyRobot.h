#pragma once
#ifndef MYROBOT_H_
#define MY_ROBOT_H_
#include "CGFobject.h"


class MyRobot : public CGFobject
{
public:
	MyRobot();
	void draw();
};
#endif