#include "MyRobot.h"

MyRobot::MyRobot()
{

}


void MyRobot::draw()
{
	glBegin(GL_TRIANGLES);
		glVertex3f(0.5, 0.3, 0);
		glVertex3f(-0.5, 0.3, 0);
		glVertex3f(0, 0.3, 2.0);
	glEnd();
}