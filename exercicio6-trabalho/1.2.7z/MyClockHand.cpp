#include "ExampleObject.h"
#include "MyClockHand.h"
#include "math.h"

float pi2 = acos(-1.0);

MyClockHand::MyClockHand(float thickness, float length, float red, float green, float blue){
	this->angle = 0;
	this->thickness = thickness;
	this->length = length;
	this->red = red;
	this->green = green;
	this->blue = blue;
}

float MyClockHand::getAngle(){
	return angle;
}

void MyClockHand::setAngle(float angle){
	this->angle = (angle*pi2)/180.0;
}

void MyClockHand::draw(){
	glBegin(GL_TRIANGLES);
		glColor3f(red, green, blue);
		glVertex3f(0, 0, 0);
		glColor3f(red, green, blue);
		glVertex3f(sin(-angle-thickness/2)*length*0.7, 0, -cos(-angle-thickness/2)*length*0.7); 
		glColor3f(red, green, blue);
		glVertex3f(sin(-angle+thickness/2)*length*0.7, 0, -cos(-angle+thickness/2)*length*0.7);
	glEnd();

	glBegin(GL_TRIANGLES);
		glColor3f(red, green, blue);
		glVertex3f(sin(-angle-thickness/2)*length*0.7, 0, -cos(-angle-thickness/2)*length*0.7); 
		glColor3f(red, green, blue);
		glVertex3f(sin(-angle)*length, 0, -cos(-angle)*length);
		glColor3f(red, green, blue);
		glVertex3f(sin(-angle+thickness/2)*length*0.7, 0, -cos(-angle+thickness/2)*length*0.7);
	glEnd();
}