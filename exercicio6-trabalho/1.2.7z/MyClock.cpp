#include "MyClock.h"
#include "myTable.h"
#include "CGFapplication.h"
#include "CGFappearance.h"
#include "myUnitCube.h"
#include <math.h>

#define secondIncrement 6
#define minuteIncrement 0.1
#define hourIncrement 0.0166666666667

MyClock::MyClock()
{
	float ambslidesAppearance[3] = {0.2, 0.2, 0.2};
	float difslidesAppearance[3] = {0.8, 0.8, 0.8};
	float specslidesAppearance[3] = {0.2, 0.2, 0.2};
	float shininessslidesAppearance = 60.f;

	clockAppearance = new CGFappearance(ambslidesAppearance,difslidesAppearance,specslidesAppearance,shininessslidesAppearance);
	clockAppearance->setTexture("clock.png");
	clockAppearance->setTextureWrap(GL_REPEAT,GL_REPEAT);

	hours = new MyClockHand(0.30, 0.5, 0.1, 0.2, 0.3);
	minutes = new MyClockHand(0.085, 0.8, 0.1, 0.2, 0.3);
	seconds = new MyClockHand(0.065, 0.8, 1.0, 0.1, 0.1);
		
	time = 0;
	nextUpdate = 1000;

	hoursAngle = 90;
	minutesAngle = 180;
	secondsAngle = 270;

	hours->setAngle(hoursAngle);
	minutes->setAngle(minutesAngle);
	seconds->setAngle(secondsAngle);

}


void MyClock::draw()
{
	//desenho do relogio com a textura
	glPushMatrix();
		GLUquadricObj *quadratic=gluNewQuadric();
		gluQuadricTexture( quadratic, GL_TRUE);
		clockAppearance->apply();
		gluCylinder(quadratic,1.0f,1.0f,5.0f,12,2);
		//clockAppearance->apply();
		gluDisk(quadratic, 0.0f, 1.0f, 12, 1);
		//clockAppearance->apply();
		glTranslatef(0.0f, 0.0f, 5.0f);
		//clockAppearance->apply();
		gluDisk(quadratic, 0.0f, 1.0f, 12, 1);
		//clockAppearance->apply();
		glTranslatef(0.0f, 0.0f, -5.0f);
		//clockAppearance->apply();
	glPopMatrix();

	
	//Ponteiros
	glPushMatrix();
		//glTranslated(0,-0.05,0)
		//este translated e scaled a baixo devem estar mal:
		glTranslated(7, 8.3, 0.2);
		glScaled(1.5, 1.5, 0.1);
		hours->draw();
		minutes->draw();
		seconds->draw();
	glPopMatrix();

	// center
	glPushMatrix();
	glRotated(90.0,1,0,0);
	glRotated(-180.0,0,1,0);
	glTranslated(0,0,-0.05);
	drawCenter();
	glPopMatrix();
}


void MyClock::update(unsigned long millis){

	time += millis;

	if (time >= nextUpdate) {
		hoursAngle += hourIncrement;
		minutesAngle += minuteIncrement;
		secondsAngle += secondIncrement;

		hours->setAngle(hoursAngle);
		minutes->setAngle(minutesAngle);
		seconds->setAngle(secondsAngle);

		nextUpdate = time + 1000000000;
	}
}
void MyClock::drawCenter(){
	float x1 = 0.0, y1 = 0.0, x2, y2, angle;
	double radius = 0.035;

	glColor3f(0.0,0.0,0.0);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(x1, y1);
	for ( angle=1.0; angle <= 360.0; angle += 0.2 ) {
		x2 = x1 + sin(angle)*radius;
		y2 = y1 + cos(angle)*radius;
		glVertex2f(x2, y2);
	}
	glEnd();
}