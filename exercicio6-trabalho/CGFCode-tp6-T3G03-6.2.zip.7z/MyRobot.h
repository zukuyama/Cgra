#pragma once
#ifndef MYROBOT_H_
#define MY_ROBOT_H_
#include "CGFobject.h"
#include <cmath>
using std::cos;
using std::sin;


class MyRobot : public CGFobject
{
private:
	float angle;
	float x, y, z;

public:
	MyRobot();
	void draw();
	void rotateLeft();
	void rotateRight();
	void setAngle(int angle);
	int getAngle() const;
	int getX() const;
	int getY() const;
	int getZ() const;
	void setX(int x);
	void setY(int y);
	void setZ(int z);
	void moveRobot(bool inverse);
	void moveForward();
	void moveBack();
	void moveRight();
	void moveLeft();
	double degToRad(double deg);
};
#endif