#ifndef My_Clock
#define My_Clock
#include "CGFobject.h"
#include "CGFappearance.h"
#include "myUnitCube.h"
#include "ExampleObject.h"
#include "MyClockHand.h"

#include <cmath>
#include <math.h>
#include <gl\GLU.h>
#include <GL\GLU.h>
using namespace std;

class MyClock : public CGFobject {

private:
	CGFappearance* clockAppearance;
	unsigned long nextUpdate, time;
	float hoursAngle, minutesAngle, secondsAngle;
	
	MyClockHand* hours;
	MyClockHand* minutes;
	MyClockHand* seconds;
public:
	MyClock();
	virtual void update(unsigned long millis);
	void drawCenter();
	void draw();
	
};



#endif
