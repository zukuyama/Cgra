#include "ExampleObject.h"
#include "MyClockHand.h"
#include "math.h"

float pi2 = acos(-1.0);

MyClockHand::MyClockHand( float length){
	this->angle = 0;

	this->length = length;
	ponteiro = new myCylinder(6, 2);
}

float MyClockHand::getAngle(){
	return angle;
}

void MyClockHand::setAngle(float angle){
	this->angle = (angle*pi2)/180.0;
}

void MyClockHand::draw(){
	
	glPushMatrix();
		glTranslated(5,4,1);
		glRotated(-angle, 0, 0, 1);
		glRotated(-90, 1, 0, 0);
		glScaled(0.02, 0.02, length);
		ponteiro->drawCylinder(10,50);
	glPopMatrix();
}