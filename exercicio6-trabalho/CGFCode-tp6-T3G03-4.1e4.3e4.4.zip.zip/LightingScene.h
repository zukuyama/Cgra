#ifndef LightingScene_H
#define LightingScene_H
#include "CGFscene.h"
#include "CGFappearance.h"
#include "myTable.h"
#include "Plane.h"
#include "myUnitCube.h"
#include "myCylinder.h"
#include "MyClock.h"
#include "MyClockHand.h"
#include "MyRobot.h"
#include <vector>
using std::vector;


class LightingScene : public CGFscene
{
public:
	LightingScene();
	void init();
	void display();
	virtual void update(unsigned long millis);
	void toggleSomething();
	MyRobot* getRobot();
	vector<CGFlight *> getLights();
	void setRobotTexture(string filename);
	void changeClockUpdate(bool update);
	void setSceneMode(GLenum mode);	


	int sceneVar;
	CGFlight* light0;
	CGFlight* light1;
	CGFlight* light2;
	CGFlight* light3;
	CGFlight* light4;
	myUnitCube* cube;
	myTable* table;
	myCylinder* cylinder;
	MyClock* clock;
	MyRobot *robot;
	
	Plane* wall;
	Plane* boardA;
	Plane* boardB;
	Plane* window;
	Plane* floor;
	
	CGFappearance* materialA;
	CGFappearance* materialB;
	CGFappearance* tableAppearance;
	CGFappearance* slidesAppearance;
	CGFappearance* boardAppearance;
	CGFappearance*  windowAppearance;
	CGFappearance*  floorAppearance;
	CGFappearance*  clockAppearance;
	CGFappearance*	robotAppearance;
	CGFappearance* landscapeAppearance;
	string robotTexture;
	GLenum curMode;
	~LightingScene();
};

#endif