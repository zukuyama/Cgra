#include "MyRobot.h"


MyRobot::MyRobot(int stacks) :
	stacks(stacks)
{
	angle = 210.0;
	x = 9;
	y = 0;
	z = 8;
	pi = acos(-1.0);

	calculateBasePoints();
	calculateTopPoints();
	calculateMiddlePoints();
}


double MyRobot::degToRad(double deg)
{
	return (deg * 3.1415926535) / 180.0;
}


void MyRobot::drawSide(double angle)
{
	glBegin(GL_QUADS);
		for(int i = 0; i < stacks; i++) {
			for(int j = 0; j < 3; j++) {
				drawVertex(vertex[i][j], angle);
				drawVertex(vertex[i][j + 1], angle);
				drawVertex(vertex[i + 1][j + 1], angle);
				drawVertex(vertex[i + 1][j], angle);
			}
		}
	glEnd();
}


void MyRobot::drawVertex(Point p, double angle)
{
	double a = degToRad(angle);
	glTexCoord2d((0.5 + p.x) * cos(a) + (0.5 - p.z) * sin(a), (0.5 - p.z) * cos(a) - (0.5 + p.x) * sin(a));
	glNormal3f(p.nx, p.ny, p.nz);
	glVertex3f(p.x, p.y, p.z);
}


void MyRobot::draw()
{
	int robotAngle = 270.0;
	glPushMatrix();
	glTranslatef(x, 0, z);
	glRotated(-angle, 0, 1, 0);
	drawSide(robotAngle);
	robotAngle += 90;
	robotAngle %= 360;
	for(int i = 0; i < 3; i++, robotAngle += 90)
	{
		robotAngle %= 360;
		glRotatef(90.0, 0, 1, 0);
		drawSide(robotAngle);	
	}
	glPopMatrix();
}


void MyRobot::setAngle(int angle)
{
	this -> angle = angle % 360;
}


double MyRobot::getAngle() const 
{
	return angle;
}


void MyRobot::setX(double x)
{
	this -> x = x;
}


void MyRobot::setZ(double z)
{
	this -> z = z;
}


void MyRobot::moveRobot(bool inverse)
{
	double radians = degToRad(angle);

	if(!inverse)
	{
		setX(x + 0.2 * cos(radians));
		setZ(z + 0.2 * sin(radians));
	} else 
	{
		setX(x - 0.2 * cos(radians));
		setZ(z - 0.2 * sin(radians));
	}
}



void MyRobot::calculateBasePoints()
{
	for(int i = 0; i < 4; i++) 
	{
		vertex[0][i].x = -0.5 + (float)i * 1/3;
		vertex[0][i].nx = 0.0;
		vertex[0][i].y = 0.0;
		vertex[0][i].ny = 0.0;
		vertex[0][i].z = 0.5;
		vertex[0][i].nz = 1.0;
	}
}


void MyRobot::calculateTopPoints()
{
	float tol = (float)-3/4 * pi;;
	float inc = pi / 6;
	
	for(int i = 0; i < 4; i++) {
		vertex[stacks][i].x = 0.25 * cos(tol + i * inc);
		vertex[0][i].nx = 0.25 * cos(tol + i * inc);
		vertex[stacks][i].y = 1.0;
		vertex[0][i].ny = 0.0;
		vertex[stacks][i].z = -0.25 * sin(tol + i * inc);
		vertex[0][i].nz = -0.25 * sin(tol + i * inc);
	}
}


void MyRobot::calculateMiddlePoints()
{
	for(int i = 1; i < 5; i++) {
		for(int j = 0; j < 4; j++) {
			vertex[i][j].x = vertex[0][j].x * (float)(stacks - i + 1)/(stacks + 1) + vertex[stacks][j].x * (float)i/(stacks + 1);
			vertex[i][j].nx = vertex[0][j].x * (float)(stacks - i + 1)/(stacks + 1) + vertex[stacks][j].x * (float)i/(stacks + 1);
			vertex[i][j].y = (float)i /(stacks + 1);
			vertex[i][j].ny = 0.0;
			vertex[i][j].z = vertex[0][j].z * (float)(stacks - i + 1)/(stacks + 1) + vertex[stacks][j].z * (float)i/(stacks + 1);
			vertex[i][j].nz = vertex[0][j].z * (float)(stacks - i + 1)/(stacks + 1) + vertex[stacks][j].z * (float)i/(stacks + 1);
		}	
	}
}