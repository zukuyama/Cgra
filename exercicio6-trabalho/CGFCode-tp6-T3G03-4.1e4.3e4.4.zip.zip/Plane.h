#pragma once

#include "CGF\CGFobject.h"
#include <iostream>
using namespace std;
class Plane
{
public:
	Plane(void);
	Plane(int n, double s, double t);
	~Plane(void);
	void draw();
	void drawCustomObject(int bx1, int bx2, int bz1, int bz2);
private:
	int _numDivisions; // Number of triangles that constitute rows/columns
	double s, t;
};
