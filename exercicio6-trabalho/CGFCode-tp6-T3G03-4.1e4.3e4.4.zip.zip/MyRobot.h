#pragma once
#ifndef MYROBOT_H_
#define MY_ROBOT_H_
#include "CGFobject.h"
#include <cmath>
#include <iostream>
#include <vector>
using std::cos;
using std::sin;
using std::cout;
using std::endl;
using std::vector;


//Each Point(vertex) of the robot has 3 coordinates 
struct Point {
	float x;
	float y;
	float z;
	float nx;
	float ny;
	float nz;
};


class MyRobot : public CGFobject
{
private:
	double angle, x, y, z, pi;
	int stacks;
	Point vertex[6][4];


public:
	MyRobot(int stacks);
	void draw();
	void drawSide(double angle);
	void drawVertex(Point p, double angle);
	void rotateLeft();
	void rotateRight();
	void setAngle(int angle);
	double getAngle() const;
	void setX(double x);
	void setZ(double z);
	void moveRobot(bool inverse);
	double degToRad(double deg);
	void calculateBasePoints();
	void calculateTopPoints();
	void calculateMiddlePoints();
};

#endif