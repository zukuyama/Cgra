#ifndef EXAMPLEOBJECT_H
#define EXAMPLEOBJECT_H

#include "CGFobject.h"


class myUnitCube: public CGFobject {
	
	public:
		void draw();
};
#endif